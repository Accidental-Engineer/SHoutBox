<?php

     include 'conn.php';
     include 'session.php';
 //condition for session :
     if($username && $password && $fname){
        header("Location: index.php");

     }
     else{
      ?>
      <html>
       <head>

         <title>SHoutBox</title>
         <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
         <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css"/>
         <link rel="stylesheet" type="text/css" href="style.css"/>
         <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css"/>
         <link rel="icon" href="shoutbox_logo_invert.png"/>
         <script src="script2.js"></script>
         <script src="jquery.js"></script>
         <script src="script.js"></script>
           <script src="scriptmain.js"></script>
         </head>
         <body>
            <div id='container'>
              <div class="head ">
                <div class="heading">
                 <div id="logoimg"><img src="shoutbox_logo_invert.png"></div><span id="logo">SHoutBox</span><span id='beta1' >Beta</span>
               </div>
               <div class="heading1">
                 <div style="float:left;width:50%;height:100%;">

                 </div>
                 <div style="float:left;width:20%;height:100%;">

                 </div>
                 <div style="float:left;position:relative;">
                  <a href = "login.php">  <div style="float:left; margin-top:20px; line-height:35px;color:green ; background:white; text-shadow:none;padding-left:3px;padding-right:3px;border-radius:3px;" >Sign in</div></a>
             </div>

             </div>
           </div>



      <?php } ?>
